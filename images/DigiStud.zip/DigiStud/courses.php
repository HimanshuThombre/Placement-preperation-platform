<?php
session_start();
require_once "config.php";
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="courses.css">
    <title>Document</title>
</head>
<body>
    <header class="logout">
        <a href="logout.php">
            <button class="sub-btn-sm">Sign Out</button>
        </a>
    </header>
    <h1>~ : Select Your Subject  : ~</h1>
    <div class="course-list">
        <div class="list-1">
            <a href="ICT/ict-1.php" >
                <button class="sub-btn">ICT</button>
            </a>
            <a href="OS/os-1.php">
                <button class="sub-btn">Operating System</button>
            </a>
            <a href="Adv_java/advjava-1.php">
                <button class="sub-btn">Adv Java</button>
            </a>
            <a href="CC/cc-1.php">
                <button class="sub-btn">Cloud Computing</button>
            </a>
        </div>
        <div class="list-1">
            <a href="MOC/moc-1.php">
                <button class="sub-btn">Mobile Communication</button>
            </a>
            <a href="IS/is-1.php">
                <button class="sub-btn">Information Security</button>
            </a>
            <a href="OOMD/oomd-1.php">
                <button class="sub-btn">OOMD</button>
            </a>
            <a href="SE/se-1.php">
                <button class="sub-btn">Software Engineering</button>
            </a>
        </div>
        <div class="list-1">
            <a href="ST/st-1.php">
                <button class="sub-btn">Software Testing</button>
            </a>
            <a href="Adbms/adbms-1.php">
                <button class="sub-btn">ADBMS</button>
            </a>
            <a href="DS/ds-1.php">
                <button class="sub-btn">Data Structure</button>
            </a>
            <a href="Python/python-1.php">
                <button class="sub-btn">Python</button>
            </a>
        </div>

    </div>
</body>
</html>