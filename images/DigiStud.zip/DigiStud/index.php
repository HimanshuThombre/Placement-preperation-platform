<?php
session_start();

if(isset($_SESSION['username']))
{
   header("location: courses.php");
   exit;
}
require_once "config.php";

$username = $password = "";
$err = "";

if ($_SERVER['REQUEST_METHOD'] == "POST"){
    if(empty(trim($_POST['username'])) || empty(trim($_POST['password'])))
    {
        $err = "Please enter username + password";
    }
    else{
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);
    }


if(empty($err))
{
    $sql = "SELECT id, username, password FROM members WHERE username = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $param_username);
    $param_username = $username;
    

    if(mysqli_stmt_execute($stmt)){
        mysqli_stmt_store_result($stmt);
        if(mysqli_stmt_num_rows($stmt) == 1)
                {
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password);
                    if(mysqli_stmt_fetch($stmt))
                    {
                        if(password_verify($password, $hashed_password))
                        {
                            session_start();
                            $_SESSION["username"] = $username;
                            $_SESSION["id"] = $id;
                            $_SESSION["loggedin"] = true;
                            header("location: courses.php"); 
                        }
                    }
                }
    }
}    
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/a23d05a320.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="index.css">
    <title>DigiStud</title>
</head>
<body>
    <nav class="navbar background" >
        <div class="logo">
            <img src="Imgs/img5.jpg" alt="logo">
            <h1>~DigiStud</h1>
        </div>
        <ul class="nav-list">
            <li><strong><a href ="#"><h1>Home</h1></a></strong></li>
            <li><strong><a href ="#About"><h1>About</h1></a></strong></li>
            <li><strong><a href ="#Contact"><h1>Contact Us</h1></a></strong></li>
            <li><strong><a href ="registration.php"><h1>Sign Up</h1></a></strong></li>
        </ul>

    </nav> 
    <section class="firstSection background1">
        <form action="" method="post">
            <div class="container">
                <h1>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Log In</h1>
                <div class="box">
                    <i class="fa fa-envelope"></i>
                    <input type="email" name="username" id="email" placeholder="Enter Your Email">
                </div>
                <div class="box">
                    <i class="fa fa-key"></i>
                    <input type="password" name="password" id="password" placeholder="Enter Your Password">
                </div>       
                <button type="submit" class="btn-log">Sign In</button>
                
                
            </div>
        </form>
    </section>
    <br>
    <section class="section section-left" id="About">
        <div class="paras">
            <strong>
                <p class="sectionTag text-big">DigiStud</p>
                <p class="sectionSubTag text-small">⦁	The DigiStud is a website which will be very helpful to the students for learning in this Digital world. <br> 
                ⦁	It contains all the standard study materials which required by the students for there well preparation. <br>
                ⦁	The main purpose of our project is to design, implement and maintaining a fully featured Study Material website.
                </p>
            </strong>
        </div>
        <div class="thumbnail">
            <img src="https://source.unsplash.com/900x800/?Laptop" alt="unplash">
        </div>
    </section>
    <section class="section " >
        <div class="paras">
            <strong>
                <p class="sectionSubTag text-small">⦁	DigiStud website is for e learning platform and also we provide best services for students. <br>
                    ⦁	DigiStud website provide various subject related information and also if any student has any quary then he/she can ask to our website for that we provided on email and also provided contact number. <br>
                    ⦁	Website is a unique way to connect with students. Because according to survey website is mostly preferred by students for data collection or for e- learning.
                </p>
            </strong>
        </div>
        <div class="thumbnail">
            <img src="https://source.unsplash.com/900x800/?programing,computer" alt="unplash">
        </div>
    </section>
    <br>
    <br>
    <br>
    <section class="section section-left">
        <br>
        <br>
        <div class="thumbnail-1">
            <img src="Imgs/shreya1.jpg" alt="unplash">
            <h2 class="text-center">&nbsp;&nbsp;&nbsp;&nbsp;SB Peherkar&nbsp;&nbsp;&nbsp;</h2>
        </div>
        <div class="thumbnail-1">
            <img src="Imgs/siddhi1.jpg" alt="unplash">
            <h2 class="text-center">&nbsp;&nbsp;&nbsp;&nbsp;Siddhi More&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h2>
        </div>
        <div class="thumbnail-1">
            <img src="Imgs/Ganu2.jpg" alt="unplash">
            <h2 class="text-center">&nbsp;&nbsp;&nbsp;&nbsp;GS Gudewar&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h2>
        </div>
    </section>
   <br>
   <br>
   <br>
    <section class="contact" id="Contact">
        <br>
        <br>
        <h1 class="text-center"> <u><b>Contact Us</b></u></h1>
        <div class="text-center">
            <i class="fa fa-university" aria-hidden="true"></i>
            <h1 class="text-center">Information Technology </h1>
            <h1 class="text-center">Government Polytechnic Aurangabad</h1>
        </div>
            
        <div class="text-center">
            <i class="fa fa-envelope"></i>
            <h1 class="text-center"> 8847746665 / 7841820609</h1>
            <h1 class="text-center">digistud120@gmail.com</h1>
        </div>
    </section>

    <footer class="background">
        <p class="text-footer">
            Copyright &copy; 2022 www.DigiStud.com - All rights reserved
        </p>
    </footer>
</body>
</html>
