<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../sub-nav.css">
    <title>DigiStud</title>
</head>
<body>
    <nav class="sub-navbar sub-background" >
        <div class="sub-logo">
            <img src="../Imgs/img5.jpg" alt="sub-logo">
            <h1>~DigiStud</h1>
        </div>
        <ul class="sub-nav-list">
            <li><strong><a href ="ds-1.php"><h1>Videos</h1></a></strong></li>
            <li><strong><a href ="ds-2.php"><h1>PDFs</h1></a></strong></li>
            <li><strong><a href ="ds-3.php"><h1>PPTs</h1></a></strong></li>
            <li><strong><a href ="ds-4.php"><h1>MCQs</h1></a</strong></li>
            <li><strong><a href ="../courses.php"><h1>Courses</h1></a</strong></li>
        </ul>
    </nav>
    
    <section class="decorate">
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21765&authkey=ALkZAX8HE0cINH8&em=2" width="50%" height="650" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21764&authkey=AJuQZAKPIOf1b60&em=2" width="50%" height="650" frameborder="0" scrolling="no"></iframe>
    </section>
    <section class="decorate">
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21767&authkey=ABeEqDX1aDb8ARQ&em=2" width="50%" height="650" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21768&authkey=AJkxvj-JGZ4_9D8&em=2" width="50%" height="650" frameborder="0" scrolling="no"></iframe>
    </section>
</body>
</html>