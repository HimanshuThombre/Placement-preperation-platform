<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../sub-nav.css">
    <title>DigiStud</title>
</head>
<body>
    <nav class="sub-navbar sub-background" >
        <div class="sub-logo">
            <img src="../Imgs/img5.jpg" alt="/sub-logo">
            <h1>~DigiStud</h1>
        </div>
        <ul class="sub-nav-list">
            <li><strong><a href ="os-1.php"><h1>Videos</h1></a></strong></li>
            <li><strong><a href ="os-2.php"><h1>PDFs</h1></a></strong></li>
            <li><strong><a href ="os-3.php"><h1>PPTs</h1></a></strong></li>
            <li><strong><a href ="os-4.php"><h1>MCQs</h1></a</strong></li>
            <li><strong><a href ="../courses.php"><h1>Courses</h1></a</strong></li>
        </ul>
    </nav>
    
    <section class="decorate">
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21671&authkey=AKJGwBLvKBzFDvw&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21673&authkey=ANPJ3QuHSAN7XpQ&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21672&authkey=AHS32Em4B7yC_as&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
    </section>
    <section class="decorate">
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21675&authkey=AOQeLrwhASdP6-0&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21674&authkey=AA65mycpPt_HTFA&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21677&authkey=AAjs9DuB6NMw77s&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
    </section>
    <section class="decorate">
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21676&authkey=ACyERng3NXju3qI&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21679&authkey=AFcFFOI7n7bcwdc&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21678&authkey=ABoJR7I13zUfJ60&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
    </section>

</body>
</html>