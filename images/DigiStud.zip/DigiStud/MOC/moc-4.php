<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../sub-nav.css">
    <title>DigiStud</title>
</head>
<body>
    <nav class="sub-navbar sub-background" >
        <div class="sub-logo">
            <img src="../Imgs/img5.jpg" alt="sub-logo">
            <h1>~DigiStud</h1>
        </div>
        <ul class="sub-nav-list">
            <li><strong><a href ="moc-1.php"><h1>Videos</h1></a></strong></li>
            <li><strong><a href ="moc-2.php"><h1>PDFs</h1></a></strong></li>
            <li><strong><a href ="moc-3.php"><h1>PPTs</h1></a></strong></li>
            <li><strong><a href ="moc-4.php"><h1>MCQs</h1></a</strong></li>
            <li><strong><a href ="../courses.php"><h1>Courses</h1></a</strong></li>
        </ul>
    </nav>
    
    <section class="decorate">
        <embed src="../Mcqs/MOC-1.pdf" type="application/pdf" width="50%" height="650px">
        <embed src="../Mcqs/MOC-2.pdf" type="application/pdf" width="50%" height="650px">
    </section>

</body>
</html>