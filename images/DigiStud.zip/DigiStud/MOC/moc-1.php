<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../sub-nav.css">
    <title>DigiStud</title>
</head>
<body>
    <nav class="sub-navbar sub-background" >
        <div class="sub-logo">
            <img src="../Imgs/img5.jpg" alt="sub-logo">
            <h1>~DigiStud</h1>
        </div>
        <ul class="sub-nav-list">
            <li><strong><a href ="moc-1.php"><h1>Videos</h1></a></strong></li>
            <li><strong><a href ="moc-2.php"><h1>PDFs</h1></a></strong></li>
            <li><strong><a href ="moc-3.php"><h1>PPTs</h1></a></strong></li>
            <li><strong><a href ="moc-4.php"><h1>MCQs</h1></a</strong></li>
            <li><strong><a href ="../courses.php"><h1>Courses</h1></a</strong></li>
        </ul>
    </nav>
    
    <section class="decorate">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?list=PLV8vIYTIdSnZMKTQSTxWbx4NGNfxyZq_N" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/YX67jm5G-mg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/Ipna8YVtMPg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </section>
    <section class="decorate">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/cJv0xeuFSCc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/Xy-jkBTkUBk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/wu8kMqvrfSc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </section>
    <section class="decorate">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/xEnrwqH8ZuM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/UO63tyQWgAI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/0GxlguRqTd8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> 
    </section>
    <section class="decorate">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/GzFM2XzdpCo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/k-CnNXuQ0pU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/qDwNvDIfKjc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </section>
</body>
</html>