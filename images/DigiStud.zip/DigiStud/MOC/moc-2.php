<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../sub-nav.css">
    <title>DigiStud</title>
</head>
<body>
    <nav class="sub-navbar sub-background" >
        <div class="sub-logo">
            <img src="../Imgs/img5.jpg" alt="sub-logo">
            <h1>~DigiStud</h1>
        </div>
        <ul class="sub-nav-list">
            <li><strong><a href ="moc-1.php"><h1>Videos</h1></a></strong></li>
            <li><strong><a href ="moc-2.php"><h1>PDFs</h1></a></strong></li>
            <li><strong><a href ="moc-3.php"><h1>PPTs</h1></a></strong></li>
            <li><strong><a href ="moc-4.php"><h1>MCQs</h1></a</strong></li>
            <li><strong><a href ="../courses.php"><h1>Courses</h1></a</strong></li>
        </ul>
    </nav>
    
    <section class="decorate">
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21780&authkey=AFfEZaQPD_qoUVU&em=2" width="50%" height="650" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21776&authkey=ADMZ_B5pJgcUB0Q&em=2" width="50%" height="650" frameborder="0" scrolling="no"></iframe>
    </section>
    <section class="decorate">
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21778&authkey=ABOUBIkuMaCjV0Q&em=2" width="50%" height="650" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21779&authkey=AFbZvyx6Pm7vKLg&em=2" width="50%" height="650" frameborder="0" scrolling="no"></iframe>
    </section>
</body>
</html>