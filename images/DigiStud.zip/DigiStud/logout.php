<?php

session_start();
$_SERVER= array();
session_destroy();
header("location: index.php");

?>