<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../sub-nav.css">
    <title>DigiStud</title>
</head>
<body>
    <nav class="sub-navbar sub-background" >
        <div class="sub-logo">
            <img src="../Imgs/img5.jpg" alt="sub-logo">
            <h1>~DigiStud</h1>
        </div>
        <ul class="sub-nav-list">
            <li><strong><a href ="is-1.php"><h1>Videos</h1></a></strong></li>
            <li><strong><a href ="is-2.php"><h1>PDFs</h1></a></strong></li>
            <li><strong><a href ="is-3.php"><h1>PPTs</h1></a></strong></li>
            <li><strong><a href ="is-4.php"><h1>MCQs</h1></a</strong></li>
            <li><strong><a href ="../courses.php"><h1>Courses</h1></a</strong></li>
        </ul>
    </nav>
    
    <section class="decorate">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?list=PLYwpaL_SFmcArHtWmbs_vXX6soTK3WEJw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/lvARQKJnwp0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/cMOWZkYVleg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </section>
    <section class="decorate">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/szHSgMWYSiQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/tSkh7zqbQwg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/mjaY0ExSmFU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </section>
    <section class="decorate">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/KOv4csT0W1s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/THSF3aiww7E" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/BdDd_Ez4iZs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </section>
    <section class="decorate">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/V0d5VdTIz_c" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/fKFKThuUdnI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/yvf3lgBxdrA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </section>
</body>
</html>