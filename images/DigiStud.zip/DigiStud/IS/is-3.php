<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../sub-nav.css">
    <title>DigiStud</title>
</head>
<body>
    <nav class="sub-navbar sub-background" >
        <div class="sub-logo">
            <img src="../Imgs/img5.jpg" alt="/sub-logo">
            <h1>~DigiStud</h1>
        </div>
        <ul class="sub-nav-list">
            <li><strong><a href ="is-1.php"><h1>Videos</h1></a></strong></li>
            <li><strong><a href ="is-2.php"><h1>PDFs</h1></a></strong></li>
            <li><strong><a href ="is-3.php"><h1>PPTs</h1></a></strong></li>
            <li><strong><a href ="is-4.php"><h1>MCQs</h1></a</strong></li>
            <li><strong><a href ="../courses.php"><h1>Courses</h1></a</strong></li>
        </ul>
    </nav>
    
    <section class="decorate">
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21694&authkey=AFOroqe1XNy1PVA&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21691&authkey=AKmHaR0Wszf4BxU&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21690&authkey=AGbnOgioe0Q1ZIs&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
    </section>
    <section class="decorate">
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21694&authkey=AFOroqe1XNy1PVA&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21697&authkey=AH2tBDGPXo94CRc&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21693&authkey=AKKnQkJSjd1jpBA&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
    </section>
    <section class="decorate">
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21695&authkey=ANwUAfQB3WJa_LM&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21696&authkey=ABQYEdswhWGRg_c&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21698&authkey=AEIRAnO57a8xc_k&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>    
    </section>

</body>
</html>