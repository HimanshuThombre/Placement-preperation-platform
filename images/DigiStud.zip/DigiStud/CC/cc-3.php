<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../sub-nav.css">
    <title>DigiStud</title>
</head>
<body>
    <nav class="sub-navbar sub-background" >
        <div class="sub-logo">
            <img src="../Imgs/img5.jpg" alt="/sub-logo">
            <h1>~DigiStud</h1>
        </div>
        <ul class="sub-nav-list">
            <li><strong><a href ="cc-1.php"><h1>Videos</h1></a></strong></li>
            <li><strong><a href ="cc-2.php"><h1>PDFs</h1></a></strong></li>
            <li><strong><a href ="cc-3.php"><h1>PPTs</h1></a></strong></li>
            <li><strong><a href ="cc-4.php"><h1>MCQs</h1></a</strong></li>
            <li><strong><a href ="../courses.php"><h1>Courses</h1></a</strong></li>
        </ul>
    </nav>
    
    <section class="decorate">
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21647&authkey=AIh8SZYlrmBgQFs&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21644&authkey=AC1xtR2-5sT3d-s&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21645&authkey=AEOGZ4I0RMnv92E&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe> 
    </section>
    <section class="decorate">
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21646&authkey=ADQyGkuJqxJQFTc&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21648&authkey=ADNKvebMJLvlBco&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21650&authkey=AMxdmz5zQTinFzk&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
    </section>
    <section class="decorate">
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21651&authkey=ABWXDzj_hZNgM1I&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21649&authkey=ABx3LfwrQJT3bDY&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
    </section>

</body>
</html>