<?php
require_once "config.php";

$username = $password = $confirm_password = "";
$username_err = $password_err = $confirm_password_err = "";

$stmt='';

if ($_SERVER['REQUEST_METHOD'] == "POST"){

    if(empty(trim($_POST["username"]))){
        $username_err = "Username cannot be blank";
    }
    else{
        $sql = "SELECT id FROM members WHERE username = ?";
        $stmt = mysqli_prepare($conn, $sql);
        if($stmt)
        {
            mysqli_stmt_bind_param($stmt, "s", $param_username);

            $param_username = trim($_POST['username']);
            if(mysqli_stmt_execute($stmt)){
                mysqli_stmt_store_result($stmt);
                if(mysqli_stmt_num_rows($stmt) == 1)
                {
                    $username_err = "This username is already taken"; 
                }
                else{
                    $username = trim($_POST['username']);
                }
            }
            else{
                echo "Something went wrong";
            }
        }
    }

    mysqli_stmt_close($stmt);

if(empty(trim($_POST['password']))){
    $password_err = "Password cannot be blank";
}
elseif(strlen(trim($_POST['password'])) < 5){
    $password_err = "Password cannot be less than 5 characters";
}
else{
    $password = trim($_POST['password']);
}

if(trim($_POST['password']) !=  trim($_POST['confirm_password'])){
    $password_err = "Passwords should match";
}

if(empty($username_err) && empty($password_err) && empty($confirm_password_err))
{
    $sql = "INSERT INTO members (username, password) VALUES (?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt)
    {
        mysqli_stmt_bind_param($stmt, "ss", $param_username, $param_password);

        $param_username = $username;
        $param_password = password_hash($password, PASSWORD_DEFAULT);

        if (mysqli_stmt_execute($stmt))
        {
            header("location: index.php");
        }
        else{
            echo "Something went wrong... cannot redirect!";
        }
    }
    mysqli_stmt_close($stmt);
}
mysqli_close($conn);
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/a23d05a320.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="index.css">
    <title>Document</title>
</head>
<body>
    <nav class="navbar background" >
        <div class="logo">
            <img src="Imgs/img5.jpg" alt="logo">
            <h1>~DigiStud</h1>
        </div>
        <ul class="nav-list">
            <li><strong><a href ="#"><h1>Home</h1></a></strong></li>
            <li><strong><a href ="#ABOUT"><h1>About</h1></a></strong></li>
            <li><strong><a href ="#CONTACT"><h1>Contact Us</h1></a></strong></li>
            <li><strong><a href ="index.php"><h1>Log In</h1></a></strong></li>
        </ul>

    </nav> 
    <section class="firstSection background1">
        <form action="" method="post" >
            <div class="container">
                <h1>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sign Up</h1>
                <div class="box-sign">
                    <i class="fa fa-envelope"></i>
                    <input type="email" name="username" id="email" placeholder="Enter Your Email">
                </div>
                <div class="box-sign">
                    <i class="fa fa-phone"></i>
                    <input type="phone" name="phone" id="phone" placeholder="Enter Your Phone No.">
                </div>
                <div class="box-sign">
                    <i class="fa fa-key"></i>
                    <input type="password" name="password" id="newpassword" placeholder="Enter Your Password">
                </div>
                <div class="box-sign">
                    <i class="fa fa-key"></i>
                    <input type="password" name="confirm_password" id="confirmpassword" placeholder="Confirm Your Password">
                </div>

                <button type = "submit"class="btn">Create</button>
        
            </div>
        </form>
    </section>
    <br>
    
    <section class="section section-left" id="ABOUT">
        <div class="paras">
            <strong>
                <p class="sectionTag text-big">DigiStud</p>
                <p class="sectionSubTag text-small">⦁	The DigiStud is a website which will be very helpful to the students for learning in this Digital world. <br> 
                    ⦁	It contains all the standard study materials which required by the students for there well preparation. <br>
                    ⦁	The main purpose of our project is to design, implement and maintaining a fully featured Study Material website.
                </p>
            </strong>
        </div>
        <div class="thumbnail">
            <img src="https://source.unsplash.com/900x800/?laptop,iphone" alt="unplash">
        </div>
    </section>
    <section class="section " >
        <div class="paras">
            <strong>
                <p class="sectionSubTag text-small">⦁	DigiStud website is for e learning platform and also we provide best services for students. <br>
                    ⦁	DigiStud website provide various subject related information and also if any student has any quary then he/she can ask to our website for that we provided on email and also provided contact number. <br>
                    ⦁	Website is a unique way to connect with students. Because according to survey website is mostly preferred by students for data collection or for e- learning.
                </p>           
            </strong>
        </div>
        <div class="thumbnail">
            <img src="https://source.unsplash.com/900x800/?coding,keyboard" alt="unplash">
        </div>
    </section>
    <br>
    <br>
    <br>

    <section class="section section-left">
        <br>
        <br>
        <div class="thumbnail-1">
            <img src="Imgs/shreya1.jpg" alt="unplash">
            <h2 class="text-center">&nbsp;&nbsp;&nbsp;&nbsp;SB Peherkar&nbsp;&nbsp;&nbsp;</h2>
        </div>
        <div class="thumbnail-1">
            <img src="Imgs/siddhi1.jpg" alt="unplash">
            <h2 class="text-center">&nbsp;&nbsp;&nbsp;&nbsp;Siddhi More&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h2>
        </div>
        <div class="thumbnail-1">
            <img src="Imgs/Ganu2.jpg" alt="unplash">
            <h2 class="text-center">&nbsp;&nbsp;&nbsp;&nbsp;GS Gudewar&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h2>
        </div>
    </section>
   <br>
   <br>
   <br>
    <section class="contact" id="CONTACT" >
        <br>
        <br>
        <h1 class="text-center"> <u><b>Contact Us</b></u></h1>
        <div class="text-center">
             <i class="fa fa-university" aria-hidden="true"></i>
            <h1 class="text-center">Information Technology </h1>
            <h1 class="text-center">Government Polytechnic Aurangabad</h1>
        </div>
            
        <div class="text-center">
            <i class="fa fa-envelope"></i>
            <h1 class="text-center"> 8847746665 / 7841820609</h1>
            <h1 class="text-center">digistud120@gmail.com</h1>
        </div>

    </section>

    <footer class="background">
        <p class="text-footer">
            Copyright &copy; 2022 www.DigiStud.com - All rights reserved
        </p>
    </footer>
</body>
</html>