<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../sub-nav.css">
    <title>DigiStud</title>
</head>
<body>
    <nav class="sub-navbar sub-background" >
        <div class="sub-logo">
            <img src="../Imgs/img5.jpg" alt="/sub-logo">
            <h1>~DigiStud</h1>
        </div>
        <ul class="sub-nav-list">
            <li><strong><a href ="oomd-1.php"><h1>Videos</h1></a></strong></li>
            <li><strong><a href ="oomd-2.php"><h1>PDFs</h1></a></strong></li>
            <li><strong><a href ="oomd-3.php"><h1>PPTs</h1></a></strong></li>
            <li><strong><a href ="oomd-4.php"><h1>MCQs</h1></a</strong></li>
            <li><strong><a href ="../courses.php"><h1>Courses</h1></a</strong></li>
        </ul>
    </nav>
   
    <section class="decorate">
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21802&authkey=AJR5egtxddquh-o&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21803&authkey=AG047yZ3zo4Yqlw&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21801&authkey=ADfrxzQlJfsHVO8&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>  
             
    </section>
    <section class="decorate">
        
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21795&authkey=AHxJbcJTdqQFf1A&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21794&authkey=AOS05U7xfuUUosc&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21799&authkey=AFIu0qF9-M6lN3A&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>

    </section>
    <section class="decorate">
        <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21798&authkey=AKnF4DxlNT5aFgY&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
                <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21800&authkey=AOj2-tcvLveTVxQ&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
                <iframe src="https://onedrive.live.com/embed?cid=F1E05FB1302A879C&resid=F1E05FB1302A879C%21797&authkey=ABAqwGdO35m8F8I&em=2" width="470" height="315" frameborder="0" scrolling="no"></iframe>
    </section>

</body>
</html>